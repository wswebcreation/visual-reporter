"use client";

import React from "react";
import styles from "./MethodItem.module.css";
import { MethodData } from "../types";
import BrowserIcon, { BrowserName } from "./BrowserIcon";
import PlatformIcon, { PlatformName } from "./PlatformIcon";

interface MethodItemProps {
  data: MethodData;
}

const MethodItem: React.FC<MethodItemProps> = ({
  data: {
    commandName,
    instanceData: { browser, deviceName, platform },
    fileData: { actualFilePath, diffFilePath },
    misMatchPercentage,
    tag,
  },
}) => {
  const notKnown = "not-known";
  const browserName = browser?.name || notKnown;
  const browserVersion =
    browser?.version === "not-known" ? notKnown : browser?.version;
  const device = deviceName || notKnown;
  const platformVersion = platform.version || notKnown;
  // The replace needs to be removed before releasing the code
  const imagePath = (
    parseFloat(misMatchPercentage) > 0
      ? `/tmp/diff${diffFilePath.split("/.tmp/diff")[1]}`
      : `/tmp/actual${actualFilePath.split("/.tmp/actual")[1]}`
  ).replace("/tmp/", "/tmp/fail/");

  return (
    <div className={styles.card}>
      <div className={styles.imageContainer}>
        <img src={imagePath} alt={`${tag} screenshot`} />
      </div>
      <div className={styles.instanceData}>
        <h4>{tag}</h4>
        <p>Method: {commandName}</p>
        <p>Mismatch: {misMatchPercentage}%</p>
        <p>
          <PlatformIcon platformName={platform.name as PlatformName} />{" "}
          {platformVersion === notKnown ? "" : platformVersion}
          <BrowserIcon
            className={styles.browserIcon}
            browserName={browserName as BrowserName}
          />{" "}
          {browserVersion}
        </p>
        {device !== notKnown && <p>Device: {device}</p>}
      </div>
    </div>
  );
};

export default MethodItem;
